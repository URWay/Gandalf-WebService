package daos;

import categorias.CategoriaDao;
import categorias.CategoriaDaoJdbc;

public class DaoFactory {

    private static final String DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static final String USER = "TSI@gandalf-pi.database.windows.net";
    private static final String PASS = "SistemasInternet123";
    private static final String URL = String.format("jdbc:sqlserver://gandalf-pi.database.windows.net;database=gandalf");

    public static CategoriaDao getCategoriaDao() {
        return new CategoriaDaoJdbc(DRIVER, URL, USER, PASS);
    }

}