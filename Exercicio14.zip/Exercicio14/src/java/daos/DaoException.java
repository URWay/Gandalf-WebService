package daos;

public class DaoException extends Exception {
    public DaoException(Throwable cause) {
        super(cause);
    }
}
