package categorias;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Produtos implements Serializable {

    private List<Produto> produto;

    protected Produtos() {
    }

    public Produtos(List<Produto> produto) {
        this.produto = produto;
    }

    @XmlElement
    public List<Produto> getProduto() {
        return produto;
    }

}