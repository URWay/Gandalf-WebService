package categorias;

import daos.DaoException;
import java.util.List;

public interface CategoriaDao {

    List<Produto> findAll() throws DaoException;
    List<Categoria> findAllCategoria() throws DaoException;
    List<Produto> findCategoria(String id) throws DaoException;

    void create(Categoria categoria) throws DaoException;

}