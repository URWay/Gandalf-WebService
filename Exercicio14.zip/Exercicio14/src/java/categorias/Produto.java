package categorias;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Produto implements Serializable{
   
    private Long idProduto;
    private String nomeProduto;
    private String descProduto;
    private double precProduto;
    private double descontoPromocao;
    private String ativoProduto;
    private int idUsuario;
    private int qtdMinEstoque;
    private String imagem;
    private Categoria categoria;
    
    protected Produto() {
    
    }
    
    public Produto(Long idProduto, String nomeProduto, String descProduto, double precProduto, double descontoPromocao, String ativoProduto, int idUsuario, int qtdMinEstoque, String imagem, Categoria categoria) {
        this.idProduto = idProduto;
        this.nomeProduto = nomeProduto;
        this.descProduto = descProduto;
        this.precProduto = precProduto;
        this.descontoPromocao = descontoPromocao;
        this.ativoProduto = ativoProduto;
        this.idUsuario = idUsuario;
        this.qtdMinEstoque = qtdMinEstoque;
        this.imagem = imagem;
        this.categoria = categoria;
    }
    
    @XmlAttribute
    public Long getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(Long idProduto) {
        this.idProduto = idProduto;
    }
    
    @XmlElement
    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }
    
    @XmlElement
    public String getDescProduto() {
        return descProduto;
    }

    public void setDescProduto(String descProduto) {
        this.descProduto = descProduto;
    }
    
    @XmlElement
    public double getPrecProduto() {
        return precProduto;
    }

    public void setPrecProduto(double precProduto) {
        this.precProduto = precProduto;
    }
    
    @XmlElement
    public double getDescontoPromocao() {
        return descontoPromocao;
    }

    public void setDescontoPromocao(double descontoPromocao) {
        this.descontoPromocao = descontoPromocao;
    }
    
    @XmlElement
    public String getAtivoProduto() {
        return ativoProduto;
    }

    public void setAtivoProduto(String ativoProduto) {
        this.ativoProduto = ativoProduto;
    }
    
    @XmlElement
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
    
    @XmlElement
    public int getQtdMinEstoque() {
        return qtdMinEstoque;
    }

    public void setQtdMinEstoque(int qtdMinEstoque) {
        this.qtdMinEstoque = qtdMinEstoque;
    }
    
    @XmlElement
    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }
    
    @XmlElement
    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    
    
    
    
}
