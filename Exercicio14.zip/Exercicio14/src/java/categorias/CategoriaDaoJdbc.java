package categorias;

import daos.DaoException;
import daos.DaoJdbc;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDaoJdbc extends DaoJdbc implements CategoriaDao {

    public CategoriaDaoJdbc(String driver, String url, String user, String pass) {
        super(driver, url, user, pass);
    }

    @Override
    public List<Produto> findAll() throws DaoException {
        List<Produto> produtos = new ArrayList<>();
        
        String sql = "SELECT "
                            + "pro.idProduto, "
                            + "pro.nomeProduto, "
                            + "pro.descProduto, "
                            + "pro.precProduto, "
                            + "pro.descontoPromocao, "
                            + "pro.ativoProduto, "
                            + "pro.idUsuario, "
                            + "pro.qtdMinEstoque "
                        + "FROM Produto as pro";
                        
        try {
            try (Connection conn = getConnection();
                    
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    // Categoria
                    //Long id = rs.getLong("idCategoria");
                    //String nome = rs.getString("nomeCategoria");
                    //String descricao = rs.getString("descCategoria");

                    //Categoria categoria = new Categoria(id, nome, descricao);
                    
                    // Produto
                    Long idProduto = rs.getLong("idProduto");
                    String nomeProduto = rs.getString("nomeProduto");
                    String descProduto = rs.getString("descProduto");
                    double precProduto = rs.getDouble("precProduto");
                    double descontoPromocao = rs.getDouble("descontoPromocao");
                    String ativoProduto = rs.getString("ativoProduto");
                    int idUsuario = rs.getInt("idUsuario");
                    int qtdMinEstoque = rs.getInt("qtdMinEstoque");
                    
                    Produto produto = new Produto(idProduto, nomeProduto, descProduto, precProduto, descontoPromocao, ativoProduto, idUsuario, qtdMinEstoque, null, null);
                    produtos.add(produto);
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            throw new DaoException(ex);
        }

        return produtos;
    }
    
    @Override
    public List<Categoria> findAllCategoria() throws DaoException {
        List<Categoria> categorias = new ArrayList<>();
                        
        try {
            try (Connection conn = getConnection();
                    
                    PreparedStatement stmt = conn.prepareStatement("select * from Categoria order by nomeCategoria");
                    ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Long id = rs.getLong("idCategoria");
                    String nome = rs.getString("nomeCategoria");
                    String descricao = rs.getString("descCategoria");

                    Categoria categoria = new Categoria(id, nome, descricao);
                    categorias.add(categoria);
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            throw new DaoException(ex);
        }

        return categorias;
    }
    
    @Override
    public List<Produto> findCategoria(String id) throws DaoException {
        List<Produto> produtos = new ArrayList<>();
        
        String sql = "SELECT "
                            + "pro.idProduto, "
                            + "pro.nomeProduto, "
                            + "pro.descProduto, "
                            + "pro.precProduto, "
                            + "pro.descontoPromocao, "
                            + "pro.ativoProduto, "
                            + "pro.idUsuario, "
                            + "pro.qtdMinEstoque "
                        + "FROM Produto as pro "
                        + " WHERE pro.idCategoria = ?";  
                        
        try {
            Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, Integer.parseInt(id));
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Long idProduto = rs.getLong("idProduto");
                String nomeProduto = rs.getString("nomeProduto");
                String descProduto = rs.getString("descProduto");
                double precProduto = rs.getDouble("precProduto");
                double descontoPromocao = rs.getDouble("descontoPromocao");
                String ativoProduto = rs.getString("ativoProduto");
                int idUsuario = rs.getInt("idUsuario");
                int qtdMinEstoque = rs.getInt("qtdMinEstoque");

                Produto produto = new Produto(idProduto, nomeProduto, descProduto, precProduto, descontoPromocao, ativoProduto, idUsuario, qtdMinEstoque, null, null);
                produtos.add(produto);
            }

        } catch (ClassNotFoundException | SQLException ex) {
            throw new DaoException(ex);
        }

        return produtos;
    }

    @Override
    public void create(Categoria categoria) throws DaoException {
        try {
            if (!categoria.isValid()) {
                throw new IllegalArgumentException("categoria");
            }
            try (Connection conn = getConnection();
                    PreparedStatement stmt = conn.prepareStatement("insert into Categoria (nomeCategoria, descCategoria) values (?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, categoria.getNome());
                stmt.setString(2, categoria.getDescricao());
                int n = stmt.executeUpdate();
                if (n == 0) {
                    throw new SQLException("Nenhum registro inserido!");
                } else {
                    try (ResultSet rs = stmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            Long id = rs.getLong(1);
                            categoria.setId(id);
                        } else {
                            throw new SQLException("Id não foi criado!");
                        }
                    }
                }
            }
        } catch (IllegalArgumentException | ClassNotFoundException | SQLException ex) {
            throw new DaoException(ex);
        }
    }

}